git clone https://github.com/opennars/OpenNARS-for-Applications
cd OpenNARS-for-Applications
sh build.sh
