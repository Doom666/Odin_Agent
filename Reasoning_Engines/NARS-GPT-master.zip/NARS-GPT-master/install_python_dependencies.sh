pip3 install openai
pip3 install matplotlib
pip3 install plotly
pip3 install pandas
pip3 install scipy
pip3 install scikit-learn
