python3 ./OpenNARS-for-Applications/misc/Networking/irc_receive.py  | python3 NarsGPT.py API_KEY=YOUR_KEY | python3 ./OpenNARS-for-Applications/misc/Networking/irc_send.py

