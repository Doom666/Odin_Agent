pip3 install requests
pip3 install matplotlib
pip3 install networkx
pip3 install pexpect
pip3 install scipy
